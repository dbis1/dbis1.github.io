# zum installieren der libraries (alternativ auch über RStudio)
# install.packages("ggplot2") and other libraries below 
library(ggplot2)
library(sqldf)

# Gute Ressourcen:
#   R: www.rdocumentation.org
#   ggplot: ggplot2.tidyverse.org/reference/
#   sqldf: www.rdocumentation.org/packages/sqldf/versions/0.4-11
#   sqlite: www.sqlite.org
? getwd # ? zeigt direkt die Dokumentation an (Fenster rechts unten)


getwd() # aktueller Pfad (sollte dein Homeverzeichnis sein)
# TODO: von hier den Pfad zu den csv Dateien angeben:
folder='....Pfad zu den CSV-Dateien....'


# lese csv Dateien
dsym = read.csv(paste(folder, 'sym.csv', sep='/'))
dhist = read.csv(paste(folder, 'hist.csv', sep='/'))


##########################################################################################
# Hausaufgabe a)
##########################################################################################

# Berechne für jedes Unternehmen den Wert (column: marketCap)
companyMarketCap = sqldf(
  "with lastPrice as (
    select * 
      from dhist sh 
        join ( select ticker, MAX(day) as maxDay from dhist group by ticker ) as shm 
          on shm.ticker = sh.ticker and sh.day = shm.maxDay
  )
  select s.ticker, s.name, s.sharesOutstanding*lp.close as marketCap, s.country, s.c_name
    from dsym s join lastPrice lp on lp.ticker = s.ticker
    order by marketCap desc")
head(companyMarketCap)






# TODO SQL: Verwende die Tabelle companyMarketCap um für jedes Land das Wertvollste Unternehmen zu finden 
maxMarketCapPerCountry = sqldf("select ....TODO..... ")

# TODO Erstelle den bar graph
ggplot(data = maxMarketCapPerCountry)
  # ....TODO.....








##########################################################################################
# Hausaufgabe b)
##########################################################################################

# berechne die performance jedes unternehmens (Close Preis am Ende des Jahres / Open Preis zu Jahresbeginn)
companyPerformance = sqldf(
  "with minMaxDays as (
    select ticker, MIN(day) minDay, MAX(day) maxDay
      from dhist
      where day >= date('2019-01-01')
        and day <= date('2019-12-31')
      group by ticker
  )
  select hmin.ticker, hmin.open as startPrice, hmax.close as endPrice, hmax.close / hmin.open as performance
    from dhist hmin
      join minMaxDays min on hmin.ticker = min.ticker and hmin.day = min.minDay
      join dhist hmax on hmin.ticker = hmax.ticker
      join minMaxDays max on hmax.ticker = max.ticker and hmax.day = max.maxDay
    order by performance desc
  ")
head(companyPerformance)

# finde das jeweils beste ('winner') und das schlechteste ('looser') Unternehmen
winnerLooser = sqldf(
  "select *, 'winner' as wltype 
    from (select * from companyPerformance order by performance desc limit 1)
   union all
   select *, 'looser' as wltype 
    from  (select * from companyPerformance order by performance asc limit 1)")
print(winnerLooser)

# finde die zu winner/looser gehörenden Kurse und normalisiere diese auf den startPreis
kursDaten = sqldf(
  "select s.ticker, s.name, s.c_name, s.currency, s.country, 
        sh.day, sh.close / wl.startPrice as relativePrice,
        wltype, performance
      from dsym s
        join dhist sh on s.ticker = sh.ticker
        join winnerLooser wl on wl.ticker = s.ticker
      where day >= date('2019-01-01')
        and day <= date('2019-12-31')")
# ändere den Datentyp von der Spalte day auf Date (für ggplot, hint: scale_x_date)
kursDaten$day = as.Date(kursDaten$day) 
head(kursDaten)





#TODO
ggplot(data=kursDaten) 
  # ....TODO.....



