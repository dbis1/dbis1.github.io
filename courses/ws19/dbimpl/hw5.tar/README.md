# Expressions

Implement an expression interpreter and an expression compiler for your database.
Your implementation should support the following type of expressions:

* **Constants**
  Constants are either 8 byte float values or 8 byte signed integers.
* **Arguments**
  Refers to a fixed index of an argument array storing 8 byte values (either floats or signed integers).
* **Cast**
  Cast an expression from one type to another.
* **Addition**
  Add two expressions.
* **Subtraction**
  Subtract two expressions.
* **Multiplication**
  Multiply two expressions.
* **Division**
  Divide two expressions.

Add your implementation to the file `expression.cpp`.

## Interpreter
For the expression interpreter, each expression type should implement the method
```c++
virtual data64_t evaluate(const data64_t* args)
```
which evaluates the expression tree given an argument array.

## Compiler
For the expression compiler, each expression type should implement the method
```c++
virtual llvm::Value* build(llvm::IRBuilder<>& builder, llvm::Value* args)
```
which generates code for the expression using the LLVM framework.
The expression compiler should then implement the method `void compile(Expression& expression)` that compiles a function `data64_t (*fnPtr)(data64_t* args)` for the expression tree.

You don't need to implement implicit type casts.
Subtrees of a binary expression (`Add`, `Sub`, `Mul`, `Div`) are guaranteed to have the same type: either a float or an integer.

## Testing
Run the benchmark `make benchmark && ARGS_COUNT=1000 OPS_COUNT=100 ./benchmark` to compare the efficiency of both approaches.

## Setup
This task requires LLVM 6.0 which must be installed separately.

Ubuntu:
```
# Install LLVM 6 via apt
sudo apt install llvm-6.0 llvm-6.0-dev llvm-6.0-tools
```
