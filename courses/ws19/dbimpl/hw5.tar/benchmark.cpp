#include "expression.hpp"
// -------------------------------------------------------------------------------------
#include "/opt/PerfEvent.hpp"
// -------------------------------------------------------------------------------------
#include <llvm/Support/TargetSelect.h>
#include <random>
// -------------------------------------------------------------------------------------
using namespace std;
using namespace dbis;
// -------------------------------------------------------------------------------------
struct TestExpression {
  /// The number of arguments
  unsigned args_count;
  /// The number of operations
  unsigned ops_count;
  /// The (sub-) expressions.
  std::vector<std::unique_ptr<Expression>> expressions;
  /// The root.
  Expression *root;

  /// The constructor.
  TestExpression(int args_count, int ops_count);
};
// ---------------------------------------------------------------------------------------------------
TestExpression::TestExpression(int args_count, int ops_count)
    : args_count(args_count), ops_count(ops_count), expressions() {

  // Allocate n integer arguments
  for (unsigned i = 0; i < args_count; ++i) {
    expressions.push_back(
        std::make_unique<Argument>(i, Expression::ValueType::INT64));
  }

  std::mt19937_64 rng(0);
  std::uniform_int_distribution<std::mt19937_64::result_type> op_dis(0, 2);
  std::uniform_int_distribution<std::mt19937_64::result_type> arg_dis(
      0, args_count - 1);

  // Now build a left-deep expression tree with all operations.
  for (unsigned i = 0; i < ops_count; ++i) {
    auto &last = *expressions.back();
    auto &arg = *expressions[arg_dis(rng)];
    switch (op_dis(rng)) {
    case 0:
      expressions.push_back(std::make_unique<AddExpression>(last, arg));
      break;
    case 1:
      expressions.push_back(std::make_unique<SubExpression>(last, arg));
      break;
    case 2:
      expressions.push_back(std::make_unique<MulExpression>(last, arg));
      break;
    default:
      assert(false);
    }
  }

  // Store the root.
  root = expressions.back().get();
}
// -------------------------------------------------------------------------------------
template <typename T> inline void DO_NOT_OPTIMIZE(T const &value) {
#if defined(__clang__)
  asm volatile("" : : "g"(value) : "memory");
#else
  asm volatile("" : : "i,r,m"(value) : "memory");
#endif
}
// -------------------------------------------------------------------------------------
int main(int argc, char **argv) {
  // -------------------------------------------------------------------------------------
  const uint64_t args_count =
      getenv("ARGS_COUNT") ? atoi(getenv("ARGS_COUNT")) : 10;
  const uint64_t ops_count =
      getenv("OPS_COUNT") ? atoi(getenv("OPS_COUNT")) : 1000;
  // -------------------------------------------------------------------------------------
  // Prepare test
  TestExpression t(args_count, ops_count);
  std::mt19937_64 rng(0);
  std::uniform_int_distribution<std::mt19937_64::result_type> dis;
  std::vector<int64_t> d(t.args_count);
  for (int i = 0; i < t.args_count; ++i) {
    d[i] = dis(rng);
  }
  // -------------------------------------------------------------------------------------
  // Init LLVM
  llvm::InitializeNativeTarget();
  llvm::InitializeNativeTargetAsmPrinter();
  llvm::LLVMContext context;
  ExpressionCompiler compiler(context);
  // -------------------------------------------------------------------------------------
  compiler.compile(*t.root);
  cout << "The generated LLVM IR" << endl;
  compiler.dump();
  // -------------------------------------------------------------------------------------
  PerfEvent e;
  {
    e.setParam("approach", "int");
    PerfEventBlock b(e, ops_count);
    DO_NOT_OPTIMIZE(t.root->evaluate(reinterpret_cast<data64_t *>(d.data())));
  }
  {
    e.setParam("approach", "com");
    PerfEventBlock b(e, ops_count);
    DO_NOT_OPTIMIZE(compiler.run(reinterpret_cast<data64_t *>(d.data())));
  }
  return 0;
}
