#include "expression.hpp"
#include <llvm/IR/TypeBuilder.h>
// -------------------------------------------------------------------------------------
// -------------------------------------------------------------------------------------
// -------------------------------------------------------------------------------------
namespace dbis {
/// Evaluate the expresion.
data64_t Expression::evaluate(const data64_t *args) { assert(false); }

/// Build the expression code.
llvm::Value *Expression::build(llvm::IRBuilder<> &builder, llvm::Value *args) {
  assert(false);
}

/// Constructor.
ExpressionCompiler::ExpressionCompiler(llvm::LLVMContext &context)
    : context(context),
      module(std::make_shared<llvm::Module>("expression_generator", context)),
      jit(), fnPtr(nullptr) {}

/// Compile an expression.
void ExpressionCompiler::compile(Expression &expression) {
  // TODO
}

/// Compile an expression.
data64_t ExpressionCompiler::run(data64_t *args) { return 0; }

/// Dump the llvm module.
void ExpressionCompiler::dump() {
  module->print(llvm::outs(),
                nullptr); // was llvm::errs(), I don't find std error  stream a
                          // suitable choice for innocent dumps.
}

llvm::Value *Constant::build(llvm::IRBuilder<> &builder, llvm::Value *args) {
  // TODO
}

data64_t Constant::evaluate(const data64_t *args) {
  // TODO
}

llvm::Value *Argument::build(llvm::IRBuilder<> &builder, llvm::Value *args) {
  // TODO
}
data64_t Argument::evaluate(const data64_t *args) {
  // TODO
}

data64_t AddExpression::evaluate(const data64_t *args) {
  // TODO
  return 0;
}

llvm::Value *AddExpression::build(llvm::IRBuilder<> &builder,
                                  llvm::Value *args) {
  // TODO
  return 0;
}

data64_t SubExpression::evaluate(const data64_t *args) {

  // TODO
  return 0;
}
llvm::Value *SubExpression::build(llvm::IRBuilder<> &builder,
                                  llvm::Value *args) {
  // TODO
}

data64_t MulExpression::evaluate(const data64_t *args) {

  // TODO
  return 0;
}
llvm::Value *MulExpression::build(llvm::IRBuilder<> &builder,
                                  llvm::Value *args) {
  // TODO
  return 0;
}

data64_t DivExpression::evaluate(const data64_t *args) {

  // TODO
  return 0;
}
llvm::Value *DivExpression::build(llvm::IRBuilder<> &builder,
                                  llvm::Value *args) {
  // TODO
  return 0;
}

llvm::Value *Cast::build(llvm::IRBuilder<> &builder, llvm::Value *args) {
  // TODO
  return 0;
}
data64_t Cast::evaluate(const data64_t *args) {
  // TODO
  return 0;
}

} // namespace dbis
