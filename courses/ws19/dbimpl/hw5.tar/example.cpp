/*
http://releases.llvm.org/6.0.0/docs/index.html
-emit-llvm -g0 -O1
godbolt.org
unsigned long sum(unsigned long *args) {
    return args[0] + args[1];
}
*/
// -------------------------------------------------------------------------------------
#include "jit.hpp"
// -------------------------------------------------------------------------------------
#include "PerfEvent.hpp"
// -------------------------------------------------------------------------------------
#include <llvm/ExecutionEngine/ExecutionEngine.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/TypeBuilder.h>
#include <llvm/Support/TargetSelect.h>
#include <random>
// -------------------------------------------------------------------------------------
using namespace std;
// -------------------------------------------------------------------------------------
template <typename T> inline void DO_NOT_OPTIMIZE(T const &value) {
#if defined(__clang__)
  asm volatile("" : : "g"(value) : "memory");
#else
  asm volatile("" : : "i,r,m"(value) : "memory");
#endif
}
// -------------------------------------------------------------------------------------
using data64_t = uint64_t;
// -------------------------------------------------------------------------------------
int main(int argc, char **argv) {
  // -------------------------------------------------------------------------------------
  // Init LLVM
  llvm::InitializeNativeTarget();
  llvm::InitializeNativeTargetAsmPrinter();
  llvm::LLVMContext context;
  std::shared_ptr<llvm::Module> module =
      std::make_shared<llvm::Module>("example_generator", context);
  JIT jit;
  // -------------------------------------------------------------------------------------
  llvm::IRBuilder<> builder(context);
  auto expressionT = llvm::TypeBuilder<data64_t(data64_t *), false>::get(
      context); // function type
  auto expressionFn = llvm::cast<llvm::Function>(module->getOrInsertFunction(
      "expression", expressionT)); // function itslef
  llvm::BasicBlock *entryBlock =
      llvm::BasicBlock::Create(context, "entry", expressionFn);
  builder.SetInsertPoint(
      entryBlock); // tell the builder to insert the following instructions at
                   // the entry of the function
  // -------------------------------------------------------------------------------------
  llvm::Value *left_v_index = llvm::ConstantInt::get(
      builder.getContext(),
      llvm::APInt(64, 0,
                  false)); // the offset for the first argument is 0, we have to
                           // represent the 0 as constant integer in LLVM

  auto left_addr = builder.CreateGEP(
      expressionFn->arg_begin(), left_v_index,
      "calculate left argument address"); // GEP stands for getelementptr
  auto left_val = builder.CreateLoad(
      llvm::Type::getInt64Ty(builder.getContext()), left_addr,
      "load left argument"); // Load the first element in the args array using the
                        // address we have just calculated
  // -------------------------------------------------------------------------------------
  // repeat the same for the right argument (second element in the args array
  // with the index 1)
  llvm::Value *right_v_index =
      llvm::ConstantInt::get(builder.getContext(), llvm::APInt(64, 1, false));

  auto right_addr = builder.CreateGEP(expressionFn->arg_begin(), right_v_index,
                                      "calculate right argument address");
  auto right_val =
      builder.CreateLoad(llvm::Type::getInt64Ty(builder.getContext()),
                         right_addr, "load right argument");

  auto returnValue = builder.CreateAdd(left_val, right_val, "add integers");

  builder.CreateRet(builder.CreateBitCast(
      returnValue, llvm::Type::getInt64Ty(builder.getContext())));
  // -------------------------------------------------------------------------------------
  llvm::Expected<JIT::ModuleHandle> module_handler = jit.addModule(module);
  data64_t (*fnPtr)(data64_t * args) =
      reinterpret_cast<data64_t (*)(data64_t *)>(
          jit.getPointerToFunction("expression"));
  // -------------------------------------------------------------------------------------e
  module->print(llvm::outs(), nullptr);
  // -------------------------------------------------------------------------------------
  {
    uint64_t input[2] = {50, 25};
    data64_t result;
    DO_NOT_OPTIMIZE(result = fnPtr(input));
    cout << result << endl;
  }
  return 0;
}
